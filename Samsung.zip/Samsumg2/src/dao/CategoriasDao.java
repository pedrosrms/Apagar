/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bean.Categorias;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author SmokeyNGT
 */
public class CategoriasDao {
    public void salva(Categorias categoria) {
        try {
            PreparedStatement statement;
            if (categoria.getId() != null) {
                statement = Conexao.getConexao().prepareStatement("UPDATE categorias SET categoria = ? WHERE id = ? AND id IS NOT NULL");
                statement.setInt(2, categoria.getId());
            } else {
                statement = Conexao.getConexao().prepareStatement("INSERT INTO categorias (cargo) VALUES (?)");
            }
            statement.setString(1, categoria.getCategoria());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public void exclui(Categorias categoria) {
        PreparedStatement statement;
        try {
            statement = Conexao.getConexao().prepareStatement("DELETE FROM categorias WHERE id = ? AND id IS NOT NULL");

            statement.setInt(1, categoria.getId());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public List retornarCategorias(String nome) {
        String nomeUpp = nome.toUpperCase() + "%";
        List<Categorias> lista = new LinkedList();

        PreparedStatement statement;

        try {
            statement = Conexao.getConexao().prepareStatement("SELECT c.id, c.categoria FROM categorias as c WHERE UPPER(c.categoria) LIKE ?");
            ResultSet resultado = statement.executeQuery();
            Conexao.getConexao().commit();
            
            while(resultado.next()){
                lista.add(new Categorias(resultado.getInt("id"), resultado.getString("categoria")));
            }
        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
           
        }return lista;
    }
}
