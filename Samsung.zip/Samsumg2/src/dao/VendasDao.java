/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bean.Cargos;
import bean.Categorias;
import bean.Clientes;
import bean.Produtos;
import bean.Usuarios;
import bean.Variacoes;
import bean.Vendas;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author SmokeyNGT
 */
public class VendasDao {
    public void salva(Vendas venda) {
        try {
            PreparedStatement statement;
            if (venda.getId() != null) {
                statement = Conexao.getConexao().prepareStatement("UPDATE vendas SET id_cliente = ?, id_usuario = ?, id_produto = ?, data = ? WHERE id = ? AND id IS NOT NULL");
                statement.setInt(5, venda.getId());
            } else {
                statement = Conexao.getConexao().prepareStatement("INSERT INTO vendas (id_cliente, id_usuario, id_produto, data) VALUES (?, ?, ?, ?)");
            }
            statement.setInt(1, venda.getCliente().getId());
            statement.setInt(2, venda.getUsuario().getId());
            statement.setInt(3, venda.getProduto().getId());
            statement.setDate(4, venda.getData());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public void exclui(Vendas venda) {
        PreparedStatement statement;
        try {
            statement = Conexao.getConexao().prepareStatement("DELETE FROM vendas WHERE id = ? AND id IS NOT NULL");

            statement.setInt(1, venda.getId());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public List retornarCargosNomes(String parametro, String opcao) {
        String parametro2 = "";
        List<Vendas> lista = new LinkedList();

        PreparedStatement statement;
        String query = "SELECT v.id, c.id AS cliente_id, c.nome AS cliente_nome, c.cpf AS cliente_cpf, c.rg AS cliente_rg, " +
            "c.data_nascimento AS cliente_data_nascimento, c.telefone AS cliente_telefone, c.email AS cliente_email, " +
            "c.sexo AS cliente_sexo, u.id AS usuario_id, u.nome AS usuario_nome, u.cpf AS usuario_cpf, u.rg AS usuario_rg, " +
            "u.data_nascimento AS usuario_data_nascimento, u.telefone AS usuario_telefone, u.email AS usuario_email, " +
            "u.sexo AS usuario_sexo, ca.id AS cargo_id, ca.cargo AS cargo_cargo, ca.salario AS cargo_salario, p.id AS produto_id, " +
            "p.produto AS produto_produto, p.preco AS produto_preco, va.id AS variacao_id, va.variacao AS variacao_variacao, " +
            "cat.id AS categoria_id, cat.categoria AS categoria_categroia, v.data FROM vendas AS v " +
            "INNER JOIN clientes AS c ON c.id = v.id_cliente " +
            "INNER JOIN usuarios AS u ON u.id = v. id_usuario " +
            "INNER JOIN cargos as ca ON ca.id = u.id_cargo " +
            "INNER JOIN produtos AS p ON p.id = v.id_produto " +
            "INNER JOIN variacoes AS va ON va.id = p.id_variacao " +
            "INNER JOIN categorias AS cat ON cat.id = p.id_categoria ";

        try {
            
            if(opcao.equals("cliente")){
                parametro2 = parametro.toUpperCase() + "%";
                query += "WHERE UPPER(c.nome) LIKE ?";
                
            }
            if(opcao.equals("usuario")){
                parametro2 = parametro.toUpperCase() + "%";
                query += "WHERE UPPER(u.nome) LIKE ?";
            }
            
            statement = Conexao.getConexao().prepareStatement(query);
            statement.setString(1, parametro2);
            ResultSet resultado = statement.executeQuery();
            Conexao.getConexao().commit();
            
            while(resultado.next()){
                lista.add(new Vendas(resultado.getInt("id"),
                                     new Clientes(resultado.getInt("cliente_id"),
                                                  resultado.getString("cliente_nome"),
                                                  resultado.getString("cliente_cpf"),
                                                  resultado.getString("cliente_rg"),
                                                  resultado.getDate("cliente_data_nascimento"),
                                                  resultado.getString("cliente_telefone"),
                                                  resultado.getString("cliente_email"),
                                                  resultado.getString("cliente_sexo")
                                                 ),
                                     new Usuarios(resultado.getInt("usuario_id"),
                                                  resultado.getString("usuario_nome"),
                                                  resultado.getString("usuario_cpf"),
                                                  resultado.getString("usuario_rg"),
                                                  resultado.getDate("usuario_data_nascimento"),
                                                  resultado.getString("usuario_telefone"),
                                                  resultado.getString("usuario_email"),
                                                  resultado.getString("usuario_sexo"),
                                                  new Cargos(resultado.getInt("cargo_id"),
                                                             resultado.getString("cargo_cargo"),
                                                             resultado.getDouble("cargo_salario")
                                                            )
                                                  ),
                                      new Produtos(resultado.getInt("protuo_id"),
                                                   resultado.getString("produto_produto"),
                                                   resultado.getDouble("produto_preco"), 
                                                   new Variacoes(resultado.getInt("variacao_id"),
                                                                 resultado.getString("variacao_variacao")
                                                                 ),
                                                   new Categorias(resultado.getInt("categoria_id"), 
                                                                  resultado.getString("categoria_categoria")
                                                                  )
                                                    ),
                                                    resultado.getDate("data")
                                    )
                         );
            }
        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
           
        }return lista;
    }
}
