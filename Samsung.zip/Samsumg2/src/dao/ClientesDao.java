/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;
import bean.Clientes;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author SmokeyNGT
 */
public class ClientesDao {
    
    public void salva(Clientes cliente) {
        try {
            PreparedStatement statement;
            if (cliente.getId() != null) {
                statement = Conexao.getConexao().prepareStatement("UPDATE clientes SET nome = ?, cpf = ?, rg = ?, data_nascimento = ?, telefone = ?, email = ?, sexo = ? WHERE id = ? AND id IS NOT NULL");
                statement.setInt(8, cliente.getId());
            } else {
                statement = Conexao.getConexao().prepareStatement("INSERT INTO clientes (nome, cpf, rg, data_nascimento, telefone, email, sexo) VALUES (?, ?, ?, ?, ?, ?, ?)");
            }
            statement.setString(1, cliente.getNome());
            statement.setString(2, cliente.getCpf());
            statement.setString(3, cliente.getRg());
            statement.setDate(4, cliente.getData_nascimento());
            statement.setString(5, cliente.getTelefone());
            statement.setString(6, cliente.getEmail());
            statement.setString(7, cliente.getSexo());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: ClientesDao - Salva:" + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public void exclui(Clientes cliente) {
        PreparedStatement statement;
        try {
            statement = Conexao.getConexao().prepareStatement("DELETE FROM clientes WHERE id = ? AND id IS NOT NULL");

            statement.setInt(1, cliente.getId());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: ClientesDao - Exclui:" + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public List retornarClientes(String nome) {
        
        List<Clientes> lista = new LinkedList();

        PreparedStatement statement;
        String query = "SELECT c.id, c.nome, c.cpf, c.rg, c.data_nascimento, c.telefone, c.email, c.sexo FROM clientes AS c WHERE c.id IS NOT NULL ";
        
         if (nome != null){ 
            query = query + "AND UPPER(c.nome) LIKE ? ";
            nome = nome.toUpperCase()+"%";
        }
                        
        query = query + "ORDER BY c.nome ASC";
        
        try {
            statement = Conexao.getConexao().prepareStatement(query);
            if (nome != null){ 
            statement.setString(1, nome);
        }
            ResultSet resultado = statement.executeQuery();
            Conexao.getConexao().commit();
            
            while(resultado.next()){
                lista.add(new Clientes(resultado.getInt("id"), resultado.getString("nome"), resultado.getString("cpf"), resultado.getString("rg"), resultado.getDate("data_nascimento"), resultado.getString("telefone"), resultado.getString("email"), resultado.getString("sexo")));
            }
        } catch (SQLException ex) {
            try {
                System.out.println("erro: ClientesDao - RetornarTodos:" + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
           
        }return lista;
    }
}
