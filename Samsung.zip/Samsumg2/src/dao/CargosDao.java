/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bean.Cargos;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;
import java.sql.ResultSet;

/**
 *
 * @author SmokeyNGT
 */
public class CargosDao {

    public void salva(Cargos cargo) {
        try {
            PreparedStatement statement;
            if (cargo.getId() != null) {
                statement = Conexao.getConexao().prepareStatement("UPDATE cargos SET cargo = ?, salario = ? WHERE id = ? AND id IS NOT NULL");
                statement.setInt(3, cargo.getId());
            } else {
                statement = Conexao.getConexao().prepareStatement("INSERT INTO cargos (cargo, salario) VALUES (?, ?)");
            }
            statement.setString(1, cargo.getCargo());
            statement.setDouble(2, cargo.getSalario());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: A" + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public void exclui(Cargos cargo) {
        PreparedStatement statement;
        try {
            statement = Conexao.getConexao().prepareStatement("DELETE FROM cargos WHERE id = ? AND id IS NOT NULL");

            statement.setInt(1, cargo.getId());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: A" + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public List retornarCargos(String nome) {
        String nomeUpp = nome.toUpperCase() + "%";
        List<Cargos> lista = new LinkedList();

        PreparedStatement statement;

        try {
            statement = Conexao.getConexao().prepareStatement("SELECT c.id, c.cargo, c.salario FROM cargos as c WHERE UPPER(c.cargo) LIKE ?");
            statement.setString(1, nomeUpp);
            ResultSet resultado = statement.executeQuery();
            Conexao.getConexao().commit();
            
            while(resultado.next()){
                lista.add(new Cargos(resultado.getInt("id"), resultado.getString("cargo"), resultado.getDouble("salario")));
            }
        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
           
        }return lista;
    }
}
