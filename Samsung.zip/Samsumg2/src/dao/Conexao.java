/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Scanner;

/**
 *
 * @author SmokeyNGT
 */
public class Conexao {
    private static Connection conexao;
    Scanner sc = new Scanner(System.in);
    
    public Conexao() throws SQLException{
        
        if(conexao == null || conexao.isClosed()){
            try{
                Class.forName("org.postgresql.Driver");
                conecta();
            }catch (ClassNotFoundException ex){
                System.out.println("Não foi possivel estabelecer a conexão");
            }
        }
    }
    public static Connection getConexao(){
        return conexao;
    }
    
    public final void conecta(){
        if(conexao == null){
            try{
                conexao = DriverManager.getConnection("jdbc:postgresql://localhost:5432/Samsung", "postgres", "VaiDarOtrec_24?");
                conexao.setAutoCommit(false);
            }catch (SQLException ex){
                System.out.println(ex.toString());
                System.out.println("Erro 4");
                System.exit(0);
            }
        }
    }
}
