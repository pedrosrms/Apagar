/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bean.Usuarios;
import bean.Cargos;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author SmokeyNGT
 */
public class Usuariosdao {
    public void salva(Usuarios usuario) {
        try {
            PreparedStatement statement;
            if (usuario.getId() != null) {
                statement = Conexao.getConexao().prepareStatement("UPDATE usuarios SET nome = ?, cpf = ?, rg = ?, data_nascimento = ?, telefone = ?, email = ?, sexo = ?, id_cargo = ? WHERE id = ? AND id IS NOT NULL");
                statement.setInt(9, usuario.getId());
            } else {
                statement = Conexao.getConexao().prepareStatement("INSERT INTO usuarios (nome, cpf, rg, data_nascimento, telefone, email, sexo, id_cargo) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            }
            statement.setString(1, usuario.getNome());
            statement.setString(2, usuario.getCpf());
            statement.setString(3, usuario.getRg());
            statement.setDate(4, usuario.getData_nascimento());
            statement.setString(5, usuario.getTelefone());
            statement.setString(6, usuario.getEmail());
            statement.setString(7, usuario.getSexo());
            statement.setInt(8, usuario.getCargo().getId());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public void exclui(Usuarios usuario) {
        PreparedStatement statement;
        try {
            statement = Conexao.getConexao().prepareStatement("DELETE FROM usuarios WHERE id = ? AND id IS NOT NULL");

            statement.setInt(1, usuario.getId());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public List retornarUsuarios(String nome) {
        String nomeUpp = nome.toUpperCase() + "%";
        List<Usuarios> lista = new LinkedList();

        PreparedStatement statement;

        try {
            statement = Conexao.getConexao().prepareStatement("SELECT u.id, u.nome, u.cpf, u.rg, u.data_nascimento, u.telefone, u.email, "
                    + "u.sexo, ca.id AS cargo_id, ca.cargo AS cargo_cargo, ca.salario as cargo_salario FROM usuarios AS u "
                    + "INNER JOIN cargos as cs on ca.id = u.id_cargo "
                    + "WHERE UPPER(u.nome) LIKE ?");
            statement.setString(1, nomeUpp);
            ResultSet resultado = statement.executeQuery();
            Conexao.getConexao().commit();
            
            while(resultado.next()){
                lista.add(new Usuarios(resultado.getInt("id"), resultado.getString("nome"), resultado.getString("cpf"), resultado.getString("rg"), resultado.getDate("data_nascimento"), resultado.getString("telefone"), resultado.getString("email"), resultado.getString("sexo"), new Cargos(resultado.getInt("cargo_id"), resultado.getString("cargo_cargo"), resultado.getDouble("cargo_salario"))));
            }
        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
           
        }return lista;
    }
}
