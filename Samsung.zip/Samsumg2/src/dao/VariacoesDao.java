/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bean.Variacoes;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author SmokeyNGT
 */
public class VariacoesDao {
    public void salva(Variacoes variacao) {
        try {
            PreparedStatement statement;
            if (variacao.getId() != null) {
                statement = Conexao.getConexao().prepareStatement("UPDATE variacoes SET variacao = ? WHERE id = ? AND id IS NOT NULL");
                statement.setInt(2, variacao.getId());
            } else {
                statement = Conexao.getConexao().prepareStatement("INSERT INTO cargos (variacao) VALUES (?)");
            }
            statement.setString(1, variacao.getVariacao());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public void exclui(Variacoes variacao) {
        PreparedStatement statement;
        try {
            statement = Conexao.getConexao().prepareStatement("DELETE FROM variacoes WHERE id = ? AND id IS NOT NULL");

            statement.setInt(1, variacao.getId());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public List retornarVariacoes(String nome) {
        String nomeUpp = nome.toUpperCase() + "%";
        List<Variacoes> lista = new LinkedList();

        PreparedStatement statement;

        try {
            statement = Conexao.getConexao().prepareStatement("SELECT v.id, v.variacao FROM variacoes as v WHERE UPPER(v.variacao) LIKE ?");
            statement.setString(1, nomeUpp);
            ResultSet resultado = statement.executeQuery();
            Conexao.getConexao().commit();
            
            while(resultado.next()){
                lista.add(new Variacoes(resultado.getInt("id"), resultado.getString("variacao")));
            }
        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
           
        }return lista;
    }
}
