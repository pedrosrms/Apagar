/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import bean.Categorias;
import bean.Produtos;
import bean.Variacoes;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author SmokeyNGT
 */
public class ProdutosDao {
     public void salva(Produtos produto) {
        try {
            PreparedStatement statement;
            if (produto.getId() != null) {
                statement = Conexao.getConexao().prepareStatement("UPDATE produtos SET produto = ?, preco = ?, id_variacao = ?, id_categoria = ? WHERE id = ? AND id IS NOT NULL");
                statement.setInt(5, produto.getId());
            } else {
                statement = Conexao.getConexao().prepareStatement("INSERT INTO produtos (produto, preco, id_variacao, id_categoria) VALUES (?, ?)");
            }
            statement.setString(1, produto.getProduto());
            statement.setDouble(2, produto.getPreco());
            statement.setInt(3, produto.getVariacao().getId());
            statement.setInt(4, produto.getCategoria().getId());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public void exclui(Produtos produto) {
        PreparedStatement statement;
        try {
            statement = Conexao.getConexao().prepareStatement("DELETE FROM produtos WHERE id = ? AND id IS NOT NULL");

            statement.setInt(1, produto.getId());

            statement.execute();
            Conexao.getConexao().commit();

        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
        }
    }

    public List retornarProdutos(String nome) {
        String nomeUpp = nome.toUpperCase() + "%";
        List<Produtos> lista = new LinkedList();

        PreparedStatement statement;

        try {
            statement = Conexao.getConexao().prepareStatement("SELECT p.id, p.produto, p.preco, va.id AS variacao_id, va.variacao AS variacao_variacao, ca.id AS categoria_id, ca.categoria AS categoria_categroia FROM produtos as p "
                    + "INNER JOIN variacoes AS va ON va.id = p.id_variacao "
                    + "INNER JOIN categorias AS ca ON ca.id = p.id_categoria "
                    + "WHERE UPPER(p.produto) LIKE ?");
            statement.setString(1, nomeUpp);
            ResultSet resultado = statement.executeQuery();
            Conexao.getConexao().commit();
            
            while(resultado.next()){
                lista.add(new Produtos(resultado.getInt("id"),
                                       resultado.getString("produto"),
                                       resultado.getDouble("preco"), 
                                       new Variacoes(resultado.getInt("variacao_id"),
                                                     resultado.getString("variacao_variacao")
                                                    ),
                                        new Categorias(resultado.getInt("categoria_id"), 
                                                       resultado.getString("categoria_categoria")
                                                      )
                                        )
                         );
            }
        } catch (SQLException ex) {
            try {
                System.out.println("erro: " + ex);
                Conexao.getConexao().rollback();
            } catch (SQLException ex1) {
                System.out.println("erro dois: " + ex1);
            }
           
        }return lista;
    }
}
