/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;

/**
 *
 * @author SmokeyNGT
 */
public class Produtos {
    private Integer id;
    private String produto;
    private double preco;
    private Variacoes variacao;
    private Categorias categoria;

    public Produtos() {
    }

    public Produtos(Integer id, String produto, double preco, Variacoes variacao, Categorias categoria) {
        this.id = id;
        this.produto = produto;
        this.preco = preco;
        this.variacao = variacao;
        this.categoria = categoria;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getProduto() {
        return produto;
    }

    public void setProduto(String produto) {
        this.produto = produto;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public Variacoes getVariacao() {
        return variacao;
    }

    public void setVariacao(Variacoes variacao) {
        this.variacao = variacao;
    }

    public Categorias getCategoria() {
        return categoria;
    }

    public void setCategoria(Categorias categoria) {
        this.categoria = categoria;
    }
    
    
}
