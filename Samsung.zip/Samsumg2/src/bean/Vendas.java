/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package bean;
import java.sql.Date;
/**
 *
 * @author SmokeyNGT
 */
public class Vendas {
    private Integer id;
    private Clientes cliente;
    private Usuarios usuario;
    private Produtos produto;
    private Date data;

    public Vendas() {
    }

    public Vendas(Integer id, Clientes cliente, Usuarios usuario, Produtos produto, Date data) {
        this.id = id;
        this.cliente = cliente;
        this.usuario = usuario;
        this.data = data;
        this.produto = produto;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Clientes getCliente() {
        return cliente;
    }

    public void setCliente(Clientes cliente) {
        this.cliente = cliente;
    }

    public Usuarios getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuarios usuario) {
        this.usuario = usuario;
    }

    public Produtos getProduto() {
        return produto;
    }

    public void setProduto(Produtos produto) {
        this.produto = produto;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }
    
    
}
